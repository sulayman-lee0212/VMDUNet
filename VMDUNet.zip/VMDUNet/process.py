import numpy as np
import SimpleITK as sitk
import os
import random
import yaml
import copy
import pdb

import numpy as np
import SimpleITK as sitk
from skimage.measure import regionprops

import os


def ResampleXYZAxis(imImage, space=(1., 1., 1.), interp=sitk.sitkLinear):
    identity1 = sitk.Transform(3, sitk.sitkIdentity)
    sp1 = imImage.GetSpacing()
    sz1 = imImage.GetSize()

    sz2 = (int(round(sz1[0] * sp1[0] * 1.0 / space[0])), int(round(sz1[1] * sp1[1] * 1.0 / space[1])),
           int(round(sz1[2] * sp1[2] * 1.0 / space[2])))

    imRefImage = sitk.Image(sz2, imImage.GetPixelIDValue())
    imRefImage.SetSpacing(space)
    imRefImage.SetOrigin(imImage.GetOrigin())
    imRefImage.SetDirection(imImage.GetDirection())

    imOutImage = sitk.Resample(imImage, imRefImage, identity1, interp)

    return imOutImage


def ResampleLabelToRef(imLabel, imRef, interp=sitk.sitkNearestNeighbor):
    identity1 = sitk.Transform(3, sitk.sitkIdentity)

    imRefImage = sitk.Image(imRef.GetSize(), imLabel.GetPixelIDValue())
    imRefImage.SetSpacing(imRef.GetSpacing())
    imRefImage.SetOrigin(imRef.GetOrigin())
    imRefImage.SetDirection(imRef.GetDirection())

    ResampledLabel = sitk.Resample(imLabel, imRefImage, identity1, interp)

    return ResampledLabel


def ITKReDirection(itkimg, target_direction=(1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0)):
    # target direction should be orthognal, i.e. (1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0)

    # permute axis
    tmp_target_direction = np.abs(np.round(np.array(target_direction))).reshape(3, 3).T
    current_direction = np.abs(np.round(itkimg.GetDirection())).reshape(3, 3).T

    permute_order = []
    if not np.array_equal(tmp_target_direction, current_direction):
        for i in range(3):
            for j in range(3):
                if np.array_equal(tmp_target_direction[i], current_direction[j]):
                    permute_order.append(j)
                    # print(i, j)
                    # print(permute_order)
                    break
        redirect_img = sitk.PermuteAxes(itkimg, permute_order)
    else:
        redirect_img = itkimg
    # flip axis
    current_direction = np.round(np.array(redirect_img.GetDirection())).reshape(3, 3).T
    current_direction = np.max(current_direction, axis=1)

    tmp_target_direction = np.array(target_direction).reshape(3, 3).T
    tmp_target_direction = np.max(tmp_target_direction, axis=1)
    flip_order = ((tmp_target_direction * current_direction) != 1)
    fliped_img = sitk.Flip(redirect_img, [bool(flip_order[0]), bool(flip_order[1]), bool(flip_order[2])])
    return fliped_img


def CropForeground(imImage, imLabel, context_size=[10, 30, 30]):
    # the context_size is in numpy indice order: z, y, x
    # Note that SimpleITK use the indice order of: x, y, z

    npImg = sitk.GetArrayFromImage(imImage)
    npLab = sitk.GetArrayFromImage(imLabel)

    mask = (npLab > 0).astype(np.uint8)  # foreground mask

    regions = regionprops(mask)
    assert len(regions) == 1

    zz, yy, xx = npImg.shape

    z, y, x = regions[0].centroid

    z_min, y_min, x_min, z_max, y_max, x_max = regions[0].bbox
    print('forground size:', z_max - z_min, y_max - y_min, x_max - x_min)

    z, y, x = int(z), int(y), int(x)

    z_min = max(0, z_min - context_size[0])
    z_max = min(zz, z_max + context_size[0])
    y_min = max(0, y_min - context_size[2])
    y_max = min(yy, y_max + context_size[2])
    x_min = max(0, x_min - context_size[1])
    x_max = min(xx, x_max + context_size[1])

    img = npImg[z_min:z_max, y_min:y_max, x_min:x_max]
    lab = npLab[z_min:z_max, y_min:y_max, x_min:x_max]

    croppedImage = sitk.GetImageFromArray(img)
    croppedLabel = sitk.GetImageFromArray(lab)

    croppedImage.SetSpacing(imImage.GetSpacing())
    croppedLabel.SetSpacing(imImage.GetSpacing())

    croppedImage.SetDirection(imImage.GetDirection())
    croppedLabel.SetDirection(imImage.GetDirection())

    return croppedImage, croppedLabel


def ResampleImage(imImage, imLabel, save_path, name, target_spacing=(1., 1., 1.)):
    assert round(imImage.GetSpacing()[0], 2) == round(imLabel.GetSpacing()[0], 2)
    assert round(imImage.GetSpacing()[1], 2) == round(imLabel.GetSpacing()[1], 2)
    assert round(imImage.GetSpacing()[2], 2) == round(imLabel.GetSpacing()[2], 2)

    assert imImage.GetSize() == imLabel.GetSize()

    spacing = imImage.GetSpacing()
    origin = imImage.GetOrigin()

    imLabel.CopyInformation(imImage)

    npimg = sitk.GetArrayFromImage(imImage).astype(np.int32)
    nplab = sitk.GetArrayFromImage(imLabel).astype(np.uint8)
    z, y, x = npimg.shape

    if not os.path.exists('%s' % (save_path)):
        os.mkdir('%s' % (save_path))

    imImage.SetDirection((1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0))
    imLabel.SetDirection((1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0))

    re_img_yz = ResampleXYZAxis(imImage, space=(spacing[0], target_spacing[1], target_spacing[2]),
                                interp=sitk.sitkBSpline)
    re_lab_yz = ResampleLabelToRef(imLabel, re_img_yz, interp=sitk.sitkNearestNeighbor)

    re_img_xyz = ResampleXYZAxis(re_img_yz, space=(target_spacing[0], target_spacing[1], target_spacing[2]),
                                 interp=sitk.sitkNearestNeighbor)
    re_lab_xyz = ResampleLabelToRef(re_lab_yz, re_img_xyz, interp=sitk.sitkNearestNeighbor)

    cropped_img, cropped_lab = CropForeground(re_img_xyz, re_lab_xyz, context_size=[30, 30, 30])  # z, y, x

    sitk.WriteImage(cropped_img, '%s/%s.nii.gz' % (save_path, name))
    sitk.WriteImage(cropped_lab, '%s/%s_gt.nii.gz' % (save_path, name))


if __name__ == '__main__':

    src_path = '/data/code2025/Q1/2025-04-07-02/kits23/'
    tgt_path = '/data/code2025/Q1/2025-04-07-02/kits23_process/'

    name_list = []
    for i in range(205, 600):
        name_list.append(i)

    if not os.path.exists(tgt_path + 'list'):
        os.mkdir('%slist' % (tgt_path))
    with open("%slist/dataset.yaml" % tgt_path, "w", encoding="utf-8") as f:
        yaml.dump(name_list, f)

    os.chdir(src_path)

    for name in name_list:
        try:
            img = sitk.ReadImage(src_path + f"case_00{name:03d}/imaging.nii.gz")
            lab = sitk.ReadImage(src_path + f"case_00{name:03d}/segmentation.nii.gz")

            ResampleImage(img, lab, tgt_path, name, (0.781625, 0.781625, 0.781625))
            # ResampleImage(img, lab, tgt_path, name, (1, 1, 1))
            print(name, 'done')
        except:
            continue


